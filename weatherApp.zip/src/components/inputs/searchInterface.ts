export type ISetCoord = (lat: number, lng: number, updateSearchHistory: boolean) => void;
