# react-bootstrap-nextjs-modular-boilerplate
Boilerplate for React/NextJS workflow with modularSCSS
